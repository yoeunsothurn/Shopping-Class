// DiscountRate interface
interface DiscountRate {
    double getServiceDiscountRate(String type);
    double getProductDiscountRate(String type);
}

// Sale class
class Sale {
    private String customerType;
    private double serviceAmount;
    private double productAmount;

    public Sale(String customerType, double serviceAmount, double productAmount) {
        this.customerType = customerType;
        this.serviceAmount = serviceAmount;
        this.productAmount = productAmount;
    }

    public double calculateServiceDiscount() {
        DiscountRate discountRate = new Customer();
        return discountRate.getServiceDiscountRate(customerType) * serviceAmount;
    }

    public double calculateProductDiscount() {
        DiscountRate discountRate = new Customer();
        return discountRate.getProductDiscountRate(customerType) * productAmount;
    }
}

// Customer class implementing DiscountRate interface
class Customer implements DiscountRate {
    @Override
    public double getServiceDiscountRate(String type) {
        switch (type.toLowerCase()) {
            case "premium":
                return 0.20;
            case "gold":
                return 0.15;
            case "silver":
                return 0.10;
            case "normal":
            default:
                return 0.0;
        }
    }

    @Override
    public double getProductDiscountRate(String type) {
        switch (type.toLowerCase()) {
            case "premium":
            case "gold":
            case "silver":
                return 0.10;
            case "normal":
            default:
                return 0.0;
        }
    }
}

