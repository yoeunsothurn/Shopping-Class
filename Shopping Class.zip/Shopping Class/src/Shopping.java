public class Shopping {
    public static void main(String[] args) {
        Sale sale = new Sale("premium", 100.0, 200.0);

        double serviceDiscount = sale.calculateServiceDiscount();
        double productDiscount = sale.calculateProductDiscount();

        System.out.println("Service Discount: " + serviceDiscount);
        System.out.println("Product Discount: " + productDiscount);
    }
}
